<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
	#app{
		position: absolute;
		top: 0;
		bottom: 0;
		width: 100%;
	}
</style>
