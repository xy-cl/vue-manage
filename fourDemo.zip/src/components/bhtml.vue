<template>
	<h1>this is bhtml page</h1>
</template>

<script>
</script>

<style>
</style>