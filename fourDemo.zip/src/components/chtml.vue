<template>
	<h1>this is chtml page</h1>
</template>

<script>
</script>

<style>
</style>